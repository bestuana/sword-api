/*
 *  globals.h
 *  ObjCSword
 *
 *  Created by Manfred Bergmann on 03.06.05.
 *  Copyright 2007 mabe. All rights reserved.
 *
 */

// Notification identifiers
