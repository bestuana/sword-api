//
//  SwordListKeyTest.h
//  MacSword2
//
//  Created by Manfred Bergmann on 10.04.09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface SwordListKeyTest : XCTestCase {
}

@end
