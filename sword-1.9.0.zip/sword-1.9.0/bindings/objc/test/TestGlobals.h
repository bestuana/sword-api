//
//  TestGlobals.h
//  ObjCSword
//
//  Created by Manfred Bergmann on 02.03.16.
//
//

#ifndef TestGlobals_h
#define TestGlobals_h

#endif /* TestGlobals_h */
